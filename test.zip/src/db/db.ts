export const db = [
  {
    name: 'Oncology',
    apiKey: '7ehdndjsjsnfhdjfkdmdbsnffhdjwl',
    dcpName: 'Frank Roland',
    dcpEmail: 'frank@gmail.com',
    dcpTelephone: 1234567890,
    id: "4"
  },
  {
    name: 'WardOne',
    apiKey: 'abgcjthydf7cgh',
    dcpName: 'Jame Edward',
    dcpEmail: 'james@gmail.com',
    dcpTelephone: 555555555,
    id: "6"
  },
  {
    name: 'WardTwo',
    apiKey: 'abgcjthydf7cgh',
    dcpName: 'Jame Edward',
    dcpEmail: 'james@gmail.com',
    dcpTelephone: 555555555,
    id: "7"
  },
  {
    name: 'WardThree',
    apiKey: 'abgcjthydf7cgh',
    dcpName: 'Jame Edward',
    dcpEmail: 'james@gmail.com',
    dcpTelephone: 555555555,
    id: "8"
  }
]
